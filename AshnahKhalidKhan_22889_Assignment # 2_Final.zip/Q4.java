import java.util.Scanner;

public class Q4
{
	public static void main(String[] args)
	{
		double[] x = new double[6];
		double[] y = new double[6];
		for (int i = 0; i < x.length; i++)
		{
			x[i] = 1970 + 10*i;
		}
		y[0] = 12;
		y[1] = 15;
		y[2] = 20;
		y[3] = 27;
		y[4] = 39;
		y[5] = 52;
		System.out.println("Stirling answer: " + Stirling(1995, 2, 2, x, y));
		System.out.println("Bessels answer: " + Bessels(1995, 2, 2, x, y));
		System.out.println("Gauss Forward answer: " + GaussForward(1995, 2, 2, x, y));
		System.out.println("Gauss Backward answer: " + GaussBackward(1995, 3, 3, x, y));
	}

	public static double GaussBackward(double X, int x0, int y0, double[] x, double[] y)
	{
		double u = findU(X, x[x0], x);
		double fx = y[y0];
		fx = fx + u*deltaY(y, 1, y0 - 1);
		fx = fx + u*(u + 1)*deltaY(y, 2, y0 - 1)/factorial(2);
		fx = fx + u*(u + 1)*(u - 1)*deltaY(y, 3, y0 - 2)/factorial(3);
		fx = fx + u*(u + 1)*(u - 1)*(u + 2)*deltaY(y, 4, y0 - 2)/factorial(4);
		fx = fx + u*(u + 1)*(u - 1)*(u + 2)*(u - 2)*deltaY(y, 5, y0 - 3)/factorial(5);
		return fx;
	}

	public static double GaussForward(double X, int x0, int y0, double[] x, double[] y)
	{
		double u = findU(X, x[x0], x);
		double fx = y[y0];
		fx = fx + u*deltaY(y, 1, y0);
		fx = fx + u*(u - 1)*deltaY(y, 2, y0 - 1)/factorial(2);
		fx = fx + u*(u - 1)*(u + 1)*deltaY(y, 3, y0 - 1)/factorial(3);
		fx = fx + u*(u - 1)*(u + 1)*(u - 2)*deltaY(y, 4, y0 - 2)/factorial(4);
		fx = fx + u*(u - 1)*(u + 1)*(u - 2)*(u + 2)*deltaY(y, 5, y0 - 2)/factorial(5);
		return fx;
	}

	public static double Stirling(double X, int x0, int y0, double[] x, double[] y)
	{
		double u = findU(X, x[x0], x);
		double fx = y[y0];
		fx = fx + (u*( deltaY(y, 1, y0) + deltaY(y, 1, y0 - 1) ) /2 );
		fx = fx + (u*u*deltaY(y, 2, y0 - 1)/factorial(2));
		fx = fx + u*((u*u) - 1)*((deltaY(y, 3, y0 - 2) + deltaY(y, 3, y0 - 1))/(2*factorial(3)));
		fx = fx + (u*u*((u*u) - 1)*deltaY(y, 4, y0 - 2)/factorial(4));
		return fx;

	}

	public static double Bessels(double X, int x0, int y0, double[] x, double[] y)
	{
		double u = findU(X, x[x0], x);
		double fx = (y[y0] + y[y0 + 1])/2.0;
		fx = fx + (u - 0.5)*deltaY(y, 1, y0);
		fx = fx + u*(u - 1)*(deltaY(y, 2, y0 - 1) + deltaY(y, 2, y0))/(2*factorial(2));
		fx = fx + u*(u - 0.5)*(u - 1)*(deltaY(y, 3, y0 - 1)/factorial(3));
		fx = fx + u*(u*u - 1)*(u - 2)*(deltaY(y, 4, y0 - 2) + deltaY(y, 4, y0 - 1))/(2*factorial(4));
		fx = fx + u*(u - 0.5)*(u*u - 1)*(u - 2)*(deltaY(y, 5, y0 - 2)/factorial(5));
		return fx;

	}

	public static double deltaY(double[] arr, int superscript, int subscript)
	{
		if (superscript == 1)
			return arr[subscript + 1] - arr[subscript];
		return deltaY(arr, superscript - 1, subscript + 1) - deltaY(arr, superscript - 1, subscript);
	}

	public static double findU(double X, double x0, double[] x)
	{
		return (X - x0)/(x[1] - x[0]);
	}

	public static double factorial(int N)
	{
		if (N == 1.0 || N == 0.0)
			return 1.0;
		return N*factorial(N - 1);
	}
}