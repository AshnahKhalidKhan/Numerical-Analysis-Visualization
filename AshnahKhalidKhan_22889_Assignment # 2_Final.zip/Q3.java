import java.util.Scanner;

public class Q3
{
	public static void main(String[] args)
	{
		double[] x = new double[4];
		double[] y = new double[4];
		for (int i = 0; i < x.length; i++)
		{
			x[i] = 1 + 0.5*i;
		}
		y[0] = 0.94084;
		y[1] = 1.32468;
		y[2] = 1.60541;
		y[3] = 1.77852;
		System.out.println("NewtonsForwardQuadratic answer: " + NewtonsForwardQuadratic(1.25, 0, 0, x, y));
		System.out.println("NewtonsForwardCubic answer: " + NewtonsForwardCubic(1.25, 0, 0, x, y));
		System.out.println("NewtonsForwardQuadratic answer: " + NewtonsForwardQuadratic(2.25, 0, 0, x, y));
		System.out.println("NewtonsForwardCubic answer: " + NewtonsForwardCubic(2.25, 0, 0, x, y));

	}

	public static double NewtonsForwardQuadratic(double X, int x0, int y0, double[] x, double[] y)
	{
		double u = findU(X, x[x0], x);
		double fx = y[y0];
		fx = fx + u*deltaY(y, 1, y0);
		fx = fx + u*(u - 1)*deltaY(y, 2, y0)/factorial(2);
		return fx;
	}

	public static double NewtonsForwardCubic(double X, int x0, int y0, double[] x, double[] y)
	{
		double u = findU(X, x[x0], x);
		double fx = y[y0];
		fx = fx + u*deltaY(y, 1, y0);
		fx = fx + u*(u - 1)*deltaY(y, 2, y0)/factorial(2);
		fx = fx + u*(u - 1)*(u - 2)*deltaY(y, 3, y0)/factorial(3);
		return fx;
	}

	public static double deltaY(double[] arr, int superscript, int subscript)
	{
		if (superscript == 1)
			return arr[subscript + 1] - arr[subscript];
		return deltaY(arr, superscript - 1, subscript + 1) - deltaY(arr, superscript - 1, subscript);
	}

	public static double findU(double X, double x0, double[] x)
	{
		return (X - x0)/(x[1] - x[0]);
	}

	public static double factorial(int N)
	{
		if (N == 1.0 || N == 0.0)
			return 1.0;
		return N*factorial(N - 1);
	}
}