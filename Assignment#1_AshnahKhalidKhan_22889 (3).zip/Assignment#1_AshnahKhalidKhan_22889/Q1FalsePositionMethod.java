import java.lang.*;
import java.util.*;

public class Q1FalsePositionMethod
{
	public static double f(double x)
	{
		return x - Math.cbrt(7);
	}

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		double a = 100000000000.0;
		double b = 100000000000.0;
		while (f(a)*f(b) > 0.0)
		{
			System.out.println("Please enter digit 'a':");
			a = sc.nextDouble();
			System.out.println("Please enter digit 'b':");
			b = sc.nextDouble();
			if (f(a)*f(b) > 0.0)
				System.out.println("f(a)f(b) > 0; please re-select initial values.\n");
		}

		System.out.println("Initial interval selected.");

		double Ea = 100000000000.0; //Approximation Error
		double E = 0.0001; //Tolerance, Change to 0.000001 for performing second half of Q5 requirements
		double c = 0.0;
		double PreviousC = c;
		int NumberOfIterations = 0;

		while (Ea >= E)
		{
			NumberOfIterations = NumberOfIterations + 1;
			c = ( a*f(b) - b*f(a) )/( f(b) - f(a) );
			System.out.println("c = " + c);
			if (f(c) == 0.0)
			{
				System.out.println("Root found!");
				break;
			}
			else
			{
				if (NumberOfIterations != 0) //Ea is not calculated on first iteration
				{
					Ea = Math.abs((c - PreviousC)/c);
					if (Ea < E)
						break;
				}
				if (f(c)*f(a) < 0.0)
					b = c;
				else if (f(c)*f(b) < 0.0)
					a = c;
				PreviousC = c;
			}
		}

		System.out.println("\nTolerance E: " + E);
		System.out.println("Current approximation Error Ea: " + Ea);
		System.out.println("Number of iterations: " + NumberOfIterations);
		System.out.println("Approximated root x: " + c);
		System.out.println("f(c): " + f(c));

		sc.close();
	}
}