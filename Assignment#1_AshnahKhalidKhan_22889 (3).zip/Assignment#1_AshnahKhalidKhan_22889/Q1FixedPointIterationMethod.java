import java.util.*;
import java.lang.*;

public class Q1FixedPointIterationMethod
{
	public static double f(double x)
	{
		return Math.pow(x, 3) - 7.0;
	}

	public static double g(double x)
	{
		return (7.0/Math.pow(x, 3)) - 1.0 + x;
	}

	public static double gderivative(double x)
	{
		return (-21/Math.pow(x, 4)) + 1;
	}

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		double a = 100000000000.0;
		double b = 100000000000.0;
		double Pn = 100000000000.0;
		while (f(a)*f(b) > 0.0)
		{
			System.out.println("Please enter digit 'a':");
			a = sc.nextDouble();
			System.out.println("Please enter digit 'b':");
			b = sc.nextDouble();
			System.out.println("Please enter digit 'Pn' between a & b:");
			Pn = sc.nextDouble();
			if (f(a)*f(b) > 0.0 && Math.abs(gderivative(a)) >= 1 && Math.abs(gderivative(b)) >= 1 && ((Pn >= a && Pn <= b) || (Pn >= b && Pn <= a)))
				System.out.println("Root does not lie in interval or |g'(x)| is not less than 1 or Pn does not lie in interval a,b; please re-select initial values.");
			
		}

		System.out.println("Initial interval selected.");

		double Ea = 100000000000.0; //Approximation Error
		double E = 0.0001; //Tolerance, Change to 0.000001 for second half of Q5 requirements
		double PreviousPn = Pn;
		int NumberOfIterations = 0;

		while (Ea >= E)
		{
			NumberOfIterations = NumberOfIterations + 1;
			Pn = g(PreviousPn);
			System.out.println(Pn);
			if (g(Pn) == 0.0)
			{
				System.out.println("Root found!");
				break;
			}
			else
			{
				if (NumberOfIterations != 0) //Ea is not calculated on first iteration
					Ea = Math.abs((Pn - PreviousPn)/Pn);
				PreviousPn = Pn;
			}
		}

		System.out.println("\nTolerance E: " + E);
		System.out.println("Current approximation Error: " + Ea);
		System.out.println("Number of iterations: " + NumberOfIterations);
		System.out.println("Approximated root x: " + Pn);
		System.out.println("f(x): " + f(Pn));
		System.out.println("g(x): " + g(Pn));

		sc.close();
	}
}