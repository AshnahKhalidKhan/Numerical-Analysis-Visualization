import java.lang.*;
import java.util.*;

public class Q1NewtonMethod
{
	public static double f(double x)
	{
		return x - Math.cbrt(7);
	}

	public static double fderivative(double x)
	{
		return 1;
	}

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		double x0 = 100000000000.0;
		System.out.println("Please enter digit 'x0':");
		x0 = sc.nextDouble();

		double Ea = 100000000000.0; //Approximation Error
		double E = 0.0001; //Tolerance, Change to 0.000001 for performing second half of Q5 requirements
		double x1 = 0.0;
		int NumberOfIterations = 0;

		while (Ea >= E)
		{
			NumberOfIterations = NumberOfIterations + 1;
			x1 = x0 - (f(x0)/fderivative(x0));
			System.out.println(x1);
			if (f(x1) == 0.0)
			{
				System.out.println("Root found!");
				break;
			}
			else
			{
				if (NumberOfIterations != 0) //Ea is not calculated on first iteration
				{
					Ea = Math.abs((x1 - x0)/x1);
					if (Ea < E)
						break;
				}
				x0 = x1;
			}
		}

		System.out.println("\nTolerance E: " + E);
		System.out.println("Current approximation Error Ea: " + Ea);
		System.out.println("Number of iterations: " + NumberOfIterations);
		System.out.println("Approximated root x: " + x1);
		System.out.println("f(x): " + f(x1));

		sc.close();
	}
}