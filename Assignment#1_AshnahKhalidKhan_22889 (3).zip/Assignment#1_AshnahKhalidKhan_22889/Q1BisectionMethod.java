import java.lang.*;
import java.util.*;

public class Q1BisectionMethod
{
	public static double f(double x)
	{
		return x - Math.cbrt(7);
	}

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		double a = 100000000000.0;
		double b = 100000000000.0;
		while (f(a)*f(b) > 0.0)
		{
			System.out.println("Please enter digit 'a':");
			a = sc.nextDouble();
			System.out.println("Please enter digit 'b':");
			b = sc.nextDouble();
			if (f(a)*f(b) > 0.0)
				System.out.println("f(a)f(b) > 0; please re-select initial values.\n");
		}

		System.out.println("Initial interval selected.");

		double Ea = 100000000000.0; //Approximation Error
		double E = 0.0001; //Tolerance, Change to 0.000001 for performing second half of Q5 requirements
		double m = 0.0;
		double PreviousM = m;
		int NumberOfIterations = 0;

		while (Ea >= E)
		{
			NumberOfIterations = NumberOfIterations + 1;
			m = (a + b)/2;
			System.out.println("m = " + m);
			if (f(m) == 0.0)
			{
				System.out.println("Root found!");
				break;
			}
			else
			{
				if (NumberOfIterations != 0) //Ea is not calculated on first iteration
				{
					Ea = Math.abs((m - PreviousM)/m);
					if (Ea < E)
						break;
				}
				if (f(m)*f(a) < 0.0)
					b = m;
				else if (f(m)*f(b) < 0.0)
					a = m;
				PreviousM = m;
			}
		}

		System.out.println("\nTolerance E: " + E);
		System.out.println("Current approximation Error Ea: " + Ea);
		System.out.println("Number of iterations: " + NumberOfIterations);
		System.out.println("Approximated root x: " + m);
		System.out.println("f(m): " + f(m));

		sc.close();
	}
}