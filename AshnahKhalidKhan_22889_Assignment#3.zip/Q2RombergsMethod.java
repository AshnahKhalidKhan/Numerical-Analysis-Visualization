import java.lang.*;
import java.util.*;

public class Q2RombergsMethod
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter value of n: 2");
		int n = 2;
		System.out.println("Please enter value of a: 0");
		double a = 0;
		System.out.println("Please enter value of b: 2");
		double b = 2;
		System.out.println("Please enter value of tolerance: 0.0001");
		double t = 0.0001;
		System.out.println("Approximate answer using Rombergs Method (with initial I calculated using Trapezoidal Rule) for tolerance 0.0001:\n" + Rombergs(a, b, n, t));

		sc.close();
	}

	public static double f(double x)
	{
		return 0.25*Math.PI*Math.pow(x, 4)*Math.cos(0.25*Math.PI*x);
	}

	public static double I(double a, double b, int n)
	{
		double[] y = new double[ n + 1 ];
		double h = (b - a)/n;
		double x;
		for (int i = 0; i < y.length; i++)
		{
			x = a + (i*h);
			y[i] = f(x);
		}
		double I = 0;
		for (int i = 0; i < y.length; i++)
		{
			if (i == 0 || i == y.length - 1)
				I = I + y[i];
			else
				I = I + 2*y[i];
		}
		I = (h*I)/2;
		return I;
	}

	public static double Rombergs(double a, double b, int n, double tolerance)
	{
		int i = 1; //Initial h points
		int size = 1; //size of array
		double Ea = tolerance;
		double newValue = I(a, b, n);
		double previousValue = 0;

		while (Ea >= tolerance)
		{
			double[] table = new double[size];
			int nextN = n;
			for (int c = 0; c < table.length; c = c + 2)
			{
				table[c] = I(a, b, nextN);
				nextN = nextN*2;
			}
			int loopiteration = 1;
			for (int c = loopiteration; c <= table.length - loopiteration; c = c + 2)
			{
				table[c] = (4*table[c + 1] - table[c - 1])/3;
				if (c + 2 >= table.length - loopiteration)
				{
					loopiteration++;
					c = loopiteration;
				}
			}
			if (i == 1)
				newValue = table[0];
			else
				newValue = (4*table[i] - table[i - 2])/3;
			Ea = Math.abs((newValue - previousValue)/newValue);
			previousValue = newValue;
			i++;
			size = size + 2;
		}
		return newValue;			
	}
}