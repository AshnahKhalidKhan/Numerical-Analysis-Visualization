import java.lang.*;
import java.util.*;

public class Q1Simpsons3-8thRule
{
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Please enter value of n:");
		int n = sc.nextInt();
		System.out.println("Please enter value of a:");
		double a = sc.nextDouble();
		System.out.println("Please enter value of b:");
		double b = sc.nextDouble();
		double[] y = new double[ n + 1 ];
		double h = (b - a)/n;
		double x;
		for (int i = 0; i < y.length; i++)
		{
			x = a + (i*h);
			y[i] = f(x);
			System.out.println("x[" + i + "] " + x + "		y[" + i + "] " + y[i]);
		}
		System.out.println("Approximate answer using Simpson's 3/8th rule: " + I(y, h));

		sc.close();
	}

	public static double f(double x)
	{
		return Math.exp( Math.sqrt( Math.log(x) ) );
	}

	public static double I(double[] y, double h)
	{
		double I = 0;
		for (int i = 0; i < y.length; i++)
		{
			if (i == 0 || i == y.length - 1)
				I = I + y[i];
			else if (i % 3 == 0)
				I = I + 2*y[i];
			else if (i % 3 != 0)
				I = I + 3*y[i];
		}
		I = (3*h*I)/8;
		return I;
	}
}