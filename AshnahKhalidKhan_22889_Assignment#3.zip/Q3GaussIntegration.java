import java.util.*;
import java.lang.*;

public class Q3GaussIntegration
{
	public static void main(String[] args)
	{
		System.out.println("For function 1 where n = 5, a = 0 and b = 1.25:");
		System.out.println("Approximate answer using Gauss integration: " + Gaussf1(0, 1.25));

		System.out.println("For function 2 where n = 5, a = 0 and b = 1:");
		System.out.println("Approximate answer using Gauss integration: " + Gaussf2(0, 1));
	}

	public static double f1(double a, double b, double u)
	{
		double x = ((b-a)*u)/2 + (b + a)/2;
		double dx = (b - a)/2;
		return Math.sin(x*x)*dx;
	}

	public static double f2(double a, double b, double u)
	{
		double x = ((b-a)*u)/2 + (b + a)/2;
		double dx = (b - a)/2;
		return Math.exp(-x*x)*dx;
	}

	public static double Gaussf1(double a, double b)
	{
		double w1 = 128.0/225.0;
		double x1  = 0;

		double w2 = (322.0 + 13.0*Math.sqrt(70.0))/900.0;
		double x2 = (1.0/3.0)*Math.sqrt(5.0 - 2.0*Math.sqrt(10.0/7.0));

		double w3 = (322.0 + 13.0*Math.sqrt(70.0))/900.0;
		double x3 = -(1.0/3.0)*Math.sqrt(5.0 - 2.0*Math.sqrt(10.0/7.0));

		double w4 = (322.0 - 13.0*Math.sqrt(70.0))/900.0;
		double x4 = (1.0/3.0)*Math.sqrt(5.0 + 2.0*Math.sqrt(10.0/7.0));

		double w5 = (322.0 - 13.0*Math.sqrt(70.0))/900.0;
		double x5 = -(1.0/3.0)*Math.sqrt(5.0 + 2.0*Math.sqrt(10.0/7.0));

		return w1*f1(a, b, x1) + w2*f1(a, b, x2) + w3*f1(a, b, x3) + w4*f1(a, b, x4) + w5*f1(a, b, x5);
	}

	public static double Gaussf2(double a, double b)
	{
		double w1 = 128.0/225.0;
		double x1  = 0;

		double w2 = (322.0 + 13.0*Math.sqrt(70.0))/900.0;
		double x2 = (1.0/3.0)*Math.sqrt(5.0 - 2.0*Math.sqrt(10.0/7.0));

		double w3 = (322.0 + 13.0*Math.sqrt(70.0))/900.0;
		double x3 = -(1.0/3.0)*Math.sqrt(5.0 - 2.0*Math.sqrt(10.0/7.0));

		double w4 = (322.0 - 13.0*Math.sqrt(70.0))/900.0;
		double x4 = (1.0/3.0)*Math.sqrt(5.0 + 2.0*Math.sqrt(10.0/7.0));

		double w5 = (322.0 - 13.0*Math.sqrt(70.0))/900.0;
		double x5 = -(1.0/3.0)*Math.sqrt(5.0 + 2.0*Math.sqrt(10.0/7.0));

		return w1*f2(a, b, x1) + w2*f2(a, b, x2) + w3*f2(a, b, x3) + w4*f2(a, b, x4) + w5*f2(a, b, x5);
	}
}